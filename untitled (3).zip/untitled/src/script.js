let timer;
let timeLeft = 25 * 60;
let isRunning = false;
let mode = 'focus';

function updateDisplay() {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  document.getElementById('timer').textContent =
    `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function startTimer() {
  if (isRunning) return;
  isRunning = true;
  timer = setInterval(() => {
    if (timeLeft > 0) {
      timeLeft--;
      updateDisplay();
    } else {
      clearInterval(timer);
      alert(`${mode === 'focus' ? 'Time to take a break!' : 'Back to work!'}`);
      isRunning = false;
    }
  }, 1000);
}

function pauseTimer() {
  clearInterval(timer);
  isRunning = false;
}

function resetTimer() {
  clearInterval(timer);
  isRunning = false;
  timeLeft = mode === 'focus' ? 25 * 60 : 5 * 60;
  updateDisplay();
}

function setMode(newMode) {
  mode = newMode;
  resetTimer();
}

updateDisplay();
